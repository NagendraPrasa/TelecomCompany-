package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DAO.IssueDAO;

public class IssueService implements IssueDAO{
	Connection con = null;
	PreparedStatement pr = null;
	@Override
	public int solveIssue(int issue_id,String solution) {
		int rows=0;
		try {
			pr=con.prepareStatement("update issue set solution=? where issue_id=?");
			pr.setString(1, solution);
			pr.setInt(2, issue_id);			
			rows=pr.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
		}
		return rows;
		
	}
}
