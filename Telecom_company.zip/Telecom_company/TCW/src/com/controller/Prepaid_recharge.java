package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.CustomerDAO;
import com.model.Customer;
import com.service.CustomerService;

/**
 * Servlet implementation class Prepaid_recharge
 */
@WebServlet("/Prepaid_recharge")
public class Prepaid_recharge extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Prepaid_recharge() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		int cin = (int)session.getAttribute("cin");
		int plan_id=(int)session.getAttribute("plan_id");
		Customer c = new Customer(cin,plan_id);
		CustomerDAO cd= new CustomerService();
		int cus=cd.rechargeOnline(cin,plan_id);
		System.out.println(cus);
		if(cus > 0){
			pw.println("<h3><i>Recharge Succesful</i></h3><br>");
			RequestDispatcher rd=request.getRequestDispatcher("Prepaid_recharge.jsp");
			rd.include(request, response);
	}
}
}
