package com.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.connection.DBConnection;
/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String admin_id=request.getParameter("admin_id");
		System.out.println(admin_id);
		String pass=request.getParameter("Pass");
		System.out.println(pass);
		boolean st=false;
		Connection con=DBConnection.getConnection1();
		try {
			PreparedStatement pr=con.prepareStatement("select * from admin where cin=? and password=?");
			//System.out.println(pr);
			pr.setString(1,admin_id);
			
		    pr.setString(2,pass);
		    ResultSet rs=pr.executeQuery();
		    st=rs.next();
		    //pw.print(st);
		    
		    if(st){
		    	session.setAttribute("cin",rs.getInt(1));
		    	session.setAttribute("password",rs.getString(2));
		    	session.setAttribute("name",rs.getString(3));
		    	session.setAttribute("contact",rs.getInt(10));
		    	session.setAttribute("email_id",rs.getString(12));
		    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
		    	rd.forward(request, response);
		    }
		    else {
		    	//System.out.println("invalid password");
		    	pw.print("<h1>Invalid UserName or Password</h1>");
		    	RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
		    	rd.include(request, response);
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
