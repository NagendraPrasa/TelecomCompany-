package com.DAO;

public interface CustomerDAO {
	//public void buyPlan(int planId,int cin);
	public int rechargeOnline(int cin,int plan_id);
	public int payOnline(int cin);
	
}
